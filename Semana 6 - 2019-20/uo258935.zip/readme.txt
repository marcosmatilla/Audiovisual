UO258935
Marcos Matilla González

Genera una cara aleatoria la cual puedes ir variando con valores aleatorios con las siguientes teclas:
	'e' cambia los ojos
	'm' cambia la boca
	'h' cambia la cabeza
	'p' cambia las pupilas
	'n' cambia la nariz
	'b' cambia las cejas
	'q' guarda en un svg el final y sale de la aplicación