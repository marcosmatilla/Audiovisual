UO258935
Marcos Matilla González

Con la tecla s activas el gorro
	Pulsando la tecla derecha cambias el gorro al siguiente
	Pulsando la tecla izquierda cambias el gorro al anterior
Con la tecla g activas las gafas

Enlace: https://youtu.be/qQYR8RvgUx4