Marcos Matilla González
UO258935

El juego comienza con 5 vidas (visibles en pantalla arriba a la derecha).
	Con la tecla 'j' comenzamos la partida.
	Pulsando la tecla 's' pondremos el modo pausa.
	Pulsando la tecla 'r' reanudaremos el juego.
Volumen de la música [-20,20] (visible en la pantalla arriba a la izquierda):
	Con la tecla '+' subimos el volumen.
	Con la tecla '-' bajamos el volumen, no es el mínimo.
Con cada rebote de la pelota con la pala, la pelota cambia de color (5 colores).
Cada 5 rebotes la velocidad de la pelota incrementa un 5%.