Marcos Matilla González
UO258935

Logotipo:
https://www.vecteezy.com/vector-art/203508-hexagon-technology-logo

Imagenes:						https://www.flickr.com/photos/keso/229943662/in/photolist-mjweU-mjwfy-hGSCt-2jPKgu7-8GpGx3-2JPrH-bd5rb8-38RS6N-2iNA1ti-FyaZYg-SF1Rxz-UdFj8F-DH5brg-2jspf1H-y5CDT-2nVq9-kJi7d7-ZGV7XX-3kApmf-5fnoE1-jxzTyF-om56KB-4RYdRb-8m4MKx-54Q8XB-mD29A-7mZt4R-g5TFN5-djvznC-w7TA-57hdpj-a9EwNb-4TpUtL-2fp6E-2fp62-HJ6E3-4tfYAZ-851KCE-6PCjRw-2fp7d-aDUbse-5JiL7j-KiGiZt-8fhfpW-51matL-4UBxPd-kxagb8-i2Ju8-4UBxRJ-2jVvmz6

https://www.flickr.com/photos/jvk/14125727/in/photolist-2fp62-HJ6E3-4tfYAZ-851KCE-6PCjRw-2fp7d-aDUbse-5JiL7j-KiGiZt-8fhfpW-51matL-4UBxPd-kxagb8-i2Ju8-4UBxRJ-2jVvmz6-pXvadJ-87jFpK-87nZvb-87jM5Z-2cKT8ou-aCBxzW-aCBxnA-nRK79F-2e4i4TM-2gfaKyU-ii3pS-artPYY-4UxiXP-81PasD-4UBxKh-4UBxMw-4UxiVk-doDnqg-Kmgf1T-8Gq8Qs-m8LrB5-8GpG9m-JwD8eU-7r5jFt-6uv1Q7-x2Ct5z-pdQriS-nwdowv-6hMnYU-G8xqw-anheMH-7qG1gM-7qKWk9-QkvdZo


Musica:
https://soundcloud.com/silkmusic

Los clips de vídeo:
https://www.videezy.com/industry/4318-silhouette-of-construction-workers-and-a-blue-sky-stock-video
https://www.videezy.com/industry/4313-construction-workers-on-a-pink-sunset-4k-stock-video


Semilla texto:
Esto me causó una gran aflicción y me hizo comprender, aunque demasiado tarde, la estupidez de iniciar un trabajo sin calcular los costos ni juzgar la capacidad para realizarlo. (Robinson crusoe)
https://app.inferkit.com/demo

Somos muy preocupados por la cantidad de desempleados con capacidades o aprendizajes de materias primas en nuestro sector en particular, pero aún que eso quede confirmado, es la precariedad que, aunque debiera verse como una modificación en la relación de dependencia, es mucho más: una negativa que cambiará de forma profunda la misma relación y promete ser un gran ahorro de tiempo y dinero que todavía no se ha alcanzado en otros sectores.


Youtube:
https://youtu.be/yOPgSc_HtLw